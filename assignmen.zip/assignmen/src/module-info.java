/**
 * 
 */
/**
 * 
 */
module assignmen {
	requires java.sql;
}